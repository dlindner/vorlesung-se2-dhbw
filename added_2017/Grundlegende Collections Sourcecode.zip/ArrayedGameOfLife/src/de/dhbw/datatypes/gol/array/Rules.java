package de.dhbw.datatypes.gol.array;

public class Rules {

	public State nextStateOf(State current, int liveNeighbours) {
		if (liveNeighbours < 2 || liveNeighbours > 3) {
			return State.dead;
		}
		if (liveNeighbours == 3) {
			return State.alive;
		}
		return current;
	}
}
