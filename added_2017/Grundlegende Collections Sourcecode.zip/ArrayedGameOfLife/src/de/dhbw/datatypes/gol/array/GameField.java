package de.dhbw.datatypes.gol.array;

import java.awt.Dimension;

public class GameField {

	private final State[][] cells;

	public GameField(Dimension size) {
		super();
		this.cells = new State[size.height][size.width];
		for (int row = 0; row < this.cells.length; row++) {
			for (int column = 0; column < this.cells[row].length; column++) {
				set(new Position(row, column), State.dead);
			}
		}
	}

	public GameField nextGeneration() {
		final GameField result = new GameField(
				new Dimension(
						this.cells.length,
						this.cells[0].length));
		final Rules rules = new Rules();
		for (int row = 0; row < this.cells.length; row++) {
			for (int column = 0; column < this.cells[row].length; column++) {
				final Position current = new Position(row, column);
				result.set(
						current,
						rules.nextStateOf(
								this.cells[row][column],
								liveNeighboursAt(current)));
			}
		}
		return result;
	}

	private int liveNeighboursAt(final Position current) {
		int result = 0;
		for (Neighbourhood alongside : Neighbourhood.values()) {
			final Position neighboured = alongside.of(current);
			if (isInsideField(neighboured)
					&& (State.alive == this.cells[neighboured.row()][neighboured.column()])) {
				result++;
			}
		}
		return result;
	}

	private boolean isInsideField(final Position position) {
		return ((position.row() >= 0 && position.row() < this.cells.length)
				&& (position.column() >= 0 && position.column() < this.cells[0].length));
	}

	public void setAlive(Position position) {
		set(position, State.alive);
	}

	protected void set(Position position, State newState) {
		this.cells[position.row()][position.column()] = newState;
	}

	@Override
	public String toString() {
		final StringBuilder result = new StringBuilder();
		for (int row = 0; row < this.cells.length; row++) {
			for (int column = 0; column < this.cells[row].length; column++) {
				result.append(this.cells[row][column]);
			}
			result.append("\n");
		}
		return result.toString();
	}
}
