package de.dhbw.datatypes.gol.map;

import static de.dhbw.datatypes.gol.map.State.alive;
import static de.dhbw.datatypes.gol.map.State.dead;
import static org.hamcrest.core.Is.is;
import static org.junit.Assert.assertThat;

import org.junit.Test;

public class RulesTest {

	/*
1. Any live cell with fewer than two live neighbours dies, as if caused by under-population.
2. Any live cell with two or three live neighbours lives on to the next generation.
3. Any live cell with more than three live neighbours dies, as if by overcrowding.
4. Any dead cell with exactly three live neighbours becomes a live cell, as if by reproduction.
	 */

	@Test
	public void underpopulation() {
		final Rules target = new Rules();
		assertThat(
				target.nextStateOf(alive, 0),
				is(dead));
		assertThat(
				target.nextStateOf(alive, 1),
				is(dead));
	}

	@Test
	public void continuation() {
		final Rules target = new Rules();
		assertThat(
				target.nextStateOf(alive, 2),
				is(alive));
		assertThat(
				target.nextStateOf(alive, 3),
				is(alive));
	}

	@Test
	public void overcrowding() {
		final Rules target = new Rules();
		assertThat(
				target.nextStateOf(alive, 4),
				is(dead));
		assertThat(
				target.nextStateOf(alive, 5),
				is(dead));
		assertThat(
				target.nextStateOf(alive, 6),
				is(dead));
		assertThat(
				target.nextStateOf(alive, 7),
				is(dead));
		assertThat(
				target.nextStateOf(alive, 8),
				is(dead));
	}

	@Test
	public void reproduction() {
		final Rules target = new Rules();
		assertThat(
				target.nextStateOf(dead, 3),
				is(alive));
	}

	@Test
	public void noZombiesPlease() {
		final Rules target = new Rules();
		assertThat(
				target.nextStateOf(dead, 2),
				is(dead));
	}
}
