package de.dhbw.datatypes.gol.map;

public enum State {
	alive("X"),
	dead(".");

	private final String representation;

	private State(String representation) {
		this.representation = representation;
	}

	@Override
	public String toString() {
		return this.representation;
	}
}
