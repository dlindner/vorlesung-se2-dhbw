package de.dhbw.datatypes.gol.map;

import java.awt.Dimension;
import java.util.HashMap;
import java.util.Map;

public class GameField {

	private final Map<Position, State> cells;
	private final Dimension size;

	public GameField(final Dimension size) {
		super();
		this.size = size;
		this.cells = new HashMap<Position, State>();
		for (int row = 0; row < size.height; row++) {
			for (int column = 0; column < size.width; column++) {
				this.cells.put(new Position(row, column), State.dead);
			}
		}
	}

	public GameField nextGeneration() {
		final GameField result = new GameField(this.size);
		final Rules rules = new Rules();
		for (int row = 0; row < this.size.height; row++) {
			for (int column = 0; column < this.size.width; column++) {
				final Position current = new Position(row, column);
				result.set(
						current,
						rules.nextStateOf(
								this.cells.get(current),
								liveNeighboursAt(current)));
			}
		}
		return result;
	}

	private int liveNeighboursAt(final Position current) {
		int result = 0;
		for (Neighbourhood alongside : Neighbourhood.values()) {
			final Position neighboured = alongside.of(current);
			if (State.alive == this.cells.get(neighboured)) {
				result++;
			}
		}
		return result;
	}

	public void setAlive(Position position) {
		set(position, State.alive);
	}

	protected void set(Position position, State newState) {
		this.cells.put(position, newState);
	}

	@Override
	public String toString() {
		final StringBuilder result = new StringBuilder();
		for (int row = 0; row < this.size.height; row++) {
			for (int column = 0; column < this.size.width; column++) {
				result.append(this.cells.get(new Position(row, column)));
			}
			result.append("\n");
		}
		return result.toString();
	}
}
