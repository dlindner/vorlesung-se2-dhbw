package de.dhbw.datatypes.gol.map;

public class Position {

	private final int row;
	private final int column;

	public Position(int row, int column) {
		super();
		this.row = row;
		this.column = column;
	}

	public Position plus(int rowOffset, int columnOffset) {
		return new Position(
				this.row + rowOffset,
				this.column + columnOffset);
	}

	public int row() {
		return this.row;
	}

	public int column() {
		return this.column;
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + column;
		result = prime * result + row;
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Position other = (Position) obj;
		if (column != other.column)
			return false;
		if (row != other.row)
			return false;
		return true;
	}
}
