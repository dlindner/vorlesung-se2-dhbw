package de.dhbw.datatypes.gol.map;

import java.awt.Dimension;

public class Main {

	public static void main(String[] args) throws Exception {
		GameField field = new GameField(new Dimension(10, 10));
		placeStructureAt(new Position(5, 5), field);
		while (true) {
			System.out.println(field);
			field = field.nextGeneration();
			Thread.sleep(750L);
		}
	}

	protected static void placeStructureAt(
			final Position topLeft,
			final GameField field) {
		field.setAlive(topLeft.plus(0, 0));
		field.setAlive(topLeft.plus(0, 1));
		field.setAlive(topLeft.plus(1, 0));
		field.setAlive(topLeft.plus(2, 0));
		field.setAlive(topLeft.plus(1, 2));
	}
}
