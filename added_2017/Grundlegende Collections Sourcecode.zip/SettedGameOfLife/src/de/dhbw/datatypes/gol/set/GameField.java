package de.dhbw.datatypes.gol.set;

import java.awt.Dimension;
import java.util.HashSet;
import java.util.Set;

public class GameField {

	private final Set<Position> liveCells;
	private final Dimension size;

	public GameField(Dimension size) {
		super();
		this.size = size;
		this.liveCells = new HashSet<Position>();
	}

	public GameField nextGeneration() {
		final GameField result = new GameField(this.size);
		final Rules rules = new Rules();
		for (int row = 0; row < this.size.height; row++) {
			for (int column = 0; column < this.size.width; column++) {
				final Position current = new Position(row, column);
				final State nextState = rules.nextStateOf(
						stateAt(current),
						liveNeighboursAt(current));
				if (State.alive == nextState) {
					result.setAlive(current);
				}
			}
		}
		return result;
	}

	private int liveNeighboursAt(final Position current) {
		int result = 0;
		for (Neighbourhood alongside : Neighbourhood.values()) {
			if (this.liveCells.contains(alongside.of(current))) {
				result++;
			}
		}
		return result;
	}

	public void setAlive(Position position) {
		this.liveCells.add(position);
	}

	@Override
	public String toString() {
		final StringBuilder result = new StringBuilder();
		for (int row = 0; row < this.size.height; row++) {
			for (int column = 0; column < this.size.width; column++) {
				result.append(stateAt(new Position(row, column)));
			}
			result.append("\n");
		}
		return result.toString();
	}

	protected State stateAt(Position position) {
		if (this.liveCells.contains(position)) {
			return State.alive;
		}
		return State.dead;
	}
}
