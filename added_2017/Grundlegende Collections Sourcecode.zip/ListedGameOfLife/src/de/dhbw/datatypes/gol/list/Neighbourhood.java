package de.dhbw.datatypes.gol.list;

public enum Neighbourhood {

	NORTH(0, -1),
	SOUTH(0, 1),
	WEST(-1, 0),
	EAST(1, 0),
	NORTHWEST(-1, -1),
	SOUTHWEST(-1, 1),
	NORTHEAST(1, -1),
	SOUTHEAST(1, 1);

	private final int rowOffset;
	private final int columnOffset;

	private Neighbourhood(int rowOffset, int columnOffset) {
		this.rowOffset = rowOffset;
		this.columnOffset = columnOffset;
	}

	public Position of(Position origin) {
		return origin.plus(
				this.rowOffset,
				this.columnOffset);
	}
}
