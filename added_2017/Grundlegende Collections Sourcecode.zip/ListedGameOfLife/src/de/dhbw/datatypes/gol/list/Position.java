package de.dhbw.datatypes.gol.list;

public class Position {

	private final int row;
	private final int column;

	public Position(int row, int column) {
		super();
		this.row = row;
		this.column = column;
	}

	public Position plus(int rowOffset, int columnOffset) {
		return new Position(
				this.row + rowOffset,
				this.column + columnOffset);
	}

	public int row() {
		return this.row;
	}

	public int column() {
		return this.column;
	}
}
