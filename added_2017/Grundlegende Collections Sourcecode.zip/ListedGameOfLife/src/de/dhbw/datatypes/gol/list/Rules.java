package de.dhbw.datatypes.gol.list;

public class Rules {

	public State nextStateOf(State current, int liveNeighbours) {
		if (liveNeighbours < 2 || liveNeighbours > 3) {
			return State.dead;
		}
		if (liveNeighbours == 3) {
			return State.alive;
		}
		return current;
	}
}
