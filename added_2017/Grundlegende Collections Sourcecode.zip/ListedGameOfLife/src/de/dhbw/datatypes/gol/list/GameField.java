package de.dhbw.datatypes.gol.list;

import java.awt.Dimension;
import java.util.ArrayList;
import java.util.List;

public class GameField {

	private final List<List<State>> rows;

	public GameField(final Dimension dimension) {
		super();
		this.rows = new ArrayList<List<State>>();
		for (int row = 0; row < dimension.height; row++) {
			final List<State> columnCells = new ArrayList<State>();
			for (int column = 0; column < dimension.width; column++) {
				columnCells.add(State.dead);
			}
			this.rows.add(columnCells);
		}
	}

	public GameField nextGeneration() {
		final GameField result = new GameField(
				new Dimension(
						this.rows.size(),
						this.rows.get(0).size()));
		final Rules rules = new Rules();
		for (int row = 0; row < this.rows.size(); row++) {
			final List<State> columnCells = this.rows.get(row);
			for (int column = 0; column < columnCells.size(); column++) {
				final Position current = new Position(row, column);
				result.set(
						current,
						rules.nextStateOf(
								columnCells.get(column),
								liveNeighboursAt(current)));
			}
		}
		return result;
	}

	private int liveNeighboursAt(final Position current) {
		int result = 0;
		for (Neighbourhood alongside : Neighbourhood.values()) {
			final Position neighboured = alongside.of(current);
			if (isInsideField(neighboured)) {
				final State neighbourState = this.rows.get(neighboured.row()).get(neighboured.column());
				if (State.alive == neighbourState) {
					result++;
				}
			}
		}
		return result;
	}

	private boolean isInsideField(final Position position) {
		return ((position.row() >= 0 && position.row() < this.rows.size())
				&& (position.column() >= 0 && position.column() < this.rows.get(position.row()).size()));
	}

	public void setAlive(Position position) {
		set(position, State.alive);
	}

	protected void set(Position position, State newState) {
		final List<State> column = this.rows.get(position.row());
		column.set(position.column(), newState);
	}

	@Override
	public String toString() {
		final StringBuilder result = new StringBuilder();
		for (List<State> column : this.rows) {
			for (State each : column) {
				result.append(each);
			}
			result.append("\n");
		}
		return result.toString();
	}
}
